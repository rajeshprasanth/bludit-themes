# Tagg theme for [Bludit CMS](https://wwww.bludit.com)

Tagg is a minimalist theme. The left sidebar shows only the tags in the system and are highlighted when a user is browsing a page with that tags.

Demo: https://varlogdiego.com

![screenshot-tagg](https://raw.githubusercontent.com/bludit-themes/tagg/master/screenshot.png)

Based on Scribbler by Amie Chen
https://tympanus.net/codrops/2018/01/12/freebie-scribbler-website-template-html-sketch/

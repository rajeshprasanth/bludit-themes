# Echo theme for Bludit

Bludit and Bootstrap version of original Echo theme for Nibbleblog by Diego Najar.

## Compatible
- Branch master - Bludit v3.5.x and up
- Branch 2.3 - Bludit v2.0.x - v2.3.x

## Author
- Diego Najar
- Paulo Nunes
- Marek Rost

## Screenshot
![screenshot-editorial](https://raw.githubusercontent.com/marekrost/echo/master/screenshot.png)

Keep It Simple
==============

Theme designed by [Styleshout](http://www.styleshout.com/), adapted for Bludit by Clickwork.

Versions
--------

2.4, August 2, 2020
- Fix icon bars (menu on smartphones).

1.0, August 14, 2018
- Release.

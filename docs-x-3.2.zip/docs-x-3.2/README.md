# Docs X theme for Bludit
Docs X is a theme to create documentation sites, with highligh syntax and based on Bootstrap.

## Compatible
- Bludit v3.x

## Author
- Diego

## License
- MIT License

## Screenshot
![screenshot-docs-x](https://github.com/bludit-themes/docs-x/raw/master/screenshot.png)

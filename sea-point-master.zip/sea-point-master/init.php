<?php
/*
	This file is loaded before start the theme
	You can add some configuration code in this file
*/

// Social Networks for icons in the footer
$socialNetworks = array(
	'github'=>'Github',
	'twitter'=>'Twitter',
	'facebook'=>'Facebook',
	'instagram'=>'Instagram',
	'codepen'=>'Codepen',
	'linkedin'=>'Linkedin'
);

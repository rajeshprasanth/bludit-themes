<div class="site-footer">
  <footer class="site-info">
    <div class="inside-site-info grid-container grid-parent">
      <div class="copyright-bar">
        <span class="copyright">
          <?php echo $site->footer(); ?>
		  Powered by <a target="_blank" class="text-white" href="https://www.bludit.com">Bludit</a> &amp; <a target="_blank" class="text-white" href="https://themes.blog7.org">themes.blog7.org</a>
        </div>
    </div>
  </footer>
</div>
<aside>
  <?php Theme::plugins('siteSidebar') ?>
</aside>
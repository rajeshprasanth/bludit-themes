# Massively theme for Bludit
This is Massively, a text-heavy, article-oriented design built around a huge background image.

## Compatible
- Bludit v3.x

## Author
- Diego

## Credits
- HTML5 UP for the HTML template
- https://html5up.net
- @ajlkn

## Images
All images used in the theme are free of use, downloaded from Unsplash.
- https://unsplash.com/

## License
- Creative Commons Attribution 3.0 License

## Screenshot
![screenshot-Massively](https://raw.githubusercontent.com/bludit-themes/massively/master/screenshot.png)

<?php defined('BLUDIT') or die('Bludit CMS.');

$socialNetworks = array(
	// Key => Label
	'github'=>'Github',
	'twitter'=>'Twitter',
	'facebook'=>'Facebook',
	'googleplus'=>'Google Plus',
	'instagram'=>'Instagram',
	'codepen'=>'Codepen',
	'linkedin'=>'Linkedin'
);

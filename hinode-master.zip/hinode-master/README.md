# 日の出 - Hinode
![Hinode Theme](https://paulglushak.com/flag-hinode.png)

**日の出** (*Hinode*) is a clean, minimal and bright theme for [Bludit](https://www.bludit.com/).

It started it's life as a commission which fell through, so I've decided to share it with everyone instead.

If you decide to use it and like it, please consider [donating/tipping](https://ko-fi.com/hxii_).

---

[Home](https://paulglushak.com/hinode)
<footer class="footer">
    <div class="container">
        <div class="col">

            <p class="m-0 text-center text-grey text-uppercase"><?php echo $site->footer(); ?><span class="ml-5">Powered
                    by<img class="mini-logo" src="<?php echo DOMAIN_THEME_IMG.'favicon.png'; ?>" /><a target="_blank"
                        class="text-grey" href="https://www.bludit.com"> Bludit</a></span></p>
        </div>
    </div>
</footer>
 <!-- footer -->
    <div class="container pt-4 pb-5 text-center">
        <div class="row">
            <small class="text-secondary">
                Powered by <a href="https://www.bludit.com/" class="fw-bold" target="_blank">Bludit</a> - Theme by <a href="https://blthemes.com/" class="fw-bold" target="_blank">BlThemes</a><br>
                &copy; 2021 <a href="<?php echo $site->url(); ?>" class="fw-bold"><?php echo $site->title(); ?></a>
            </small>
        </div>
    </div>
<!--/ footer -->
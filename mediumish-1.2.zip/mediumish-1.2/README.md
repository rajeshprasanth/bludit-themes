# Mediumish theme for Bludit
Mediumish is a Bludit theme like Medium. Similar look and feel, Mediumish is the perfect blog theme.

## Features
- Bootstrap 4.0
- Responsive
- Cross Browser Compatible
- Masonry
- Font Awesome

## Base on
- Mediumish - Free Bootstrap 4.0 HTML Template Medium Styled
- https://www.wowthemes.net/mediumish-free-bootstrap-4-0-html-template-medium-styled/

## Compatible
- Bludit v3.x

## Author
- Diego

## License
- Freebies License. https://www.wowthemes.net/freebies-license/

## Screenshot
![screenshot-clean-blog](https://raw.githubusercontent.com/bludit-themes/mediumish/master/screenshot.png)

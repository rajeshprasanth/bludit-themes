# Log theme for Bludit
Theme based on Future Imperfect by [HTML5 UP](https://html5up.net).

## Compatible
- Bludit v3.x

## Author
- Diego

## Credits
- HTML5 UP for the HTML template
- https://html5up.net

## License
- Creative Commons Attribution 3.0 License

## Screenshot
![screenshot](https://raw.githubusercontent.com/bludit-themes/log/master/screenshot.png)

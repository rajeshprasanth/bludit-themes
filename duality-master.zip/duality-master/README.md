# Duality theme for Bludit
Theme for Bludit designed by Colapiombo.  

Editorial designed by HTML5-UP team is a perfect theme for a website magazine.  
Suitable for online magazines, newspaper, publishing, personal blogs and any kind of sites.  
Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)  


## Compatible
- Bludit v3.13

## Author
- Colapiombo


## Credits
- HTML5 UP for the HTML template
- https://html5up.net
- @ajlkn

## Screenshot
![screenshot-editorial](https://raw.githubusercontent.com/colapiombo/duality/master/screenshot.png)

![u](https://drive.google.com/uc?export=view&id=1ifiELvRvXhOP1RlrAra2WZFojUXGn829)

This is μ, a minimal theme for [Bludit](https://github.com/bludit/bludit).

What do you end up with when you strip away ~~the noise~~ everything?

- Single PHP file for entry listing and entry page. Categories are only mentioned but not used. Tags are unused.
- 666 bytes of CSS. 539 minified.
- Don't want 666 bytes of CSS? Add `textonly` to your request (e.g. http://dev.glushak.net/how?textonly) to serve HTML alone.
- Responsive.
- Dark mode as well.

[View Demo](http://dev.glushak.net/)
# Striped theme for Bludit

## Compatible
- Bludit v3.x

## Author
- Diego

## Credits
- HTML5 UP for the HTML template
- https://html5up.net
- @ajlkn

## License
- Creative Commons Attribution 3.0 License

## Screenshot
![screenshot-editorial](https://raw.githubusercontent.com/bludit-themes/striped/master/screenshot.png)

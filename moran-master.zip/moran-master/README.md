# Moran theme for Bludit
Moran is a simple and minimalistic theme based on [Moran](https://github.com/echenley/moran) theme for Ghost. 

## Features
- Cover image support
- Fully responsive
- Footer with social links
- Static pages are automatically added to the navbar

## Compatible
- Bludit v3.x

## Author
- Viktor G.

## Screenshot
![screenshot-moran](https://github.com/vikgor/moran/blob/master/screenshot.png)

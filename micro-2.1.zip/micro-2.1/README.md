# Micro theme for Bludit
Theme for microblogging or microsites, supports cover images, static pages, RSS and sitemap plugins.

## Compatible
- Bludit v3.4
- Bludit v2.x

## Author
- Diego

## Screenshot
![screenshot](https://raw.githubusercontent.com/bludit-themes/micro/master/screenshot.png)

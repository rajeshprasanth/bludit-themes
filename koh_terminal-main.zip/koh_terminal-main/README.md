# KOH Terminal Theme
made for [Bludit](https://www.bludit.com/)

## Intro
Work is in progress, no reason to use it now, but worth to check ;)

## Install
Asuming you have an existing Bludit installation in your Webroot, go to `bl-themes` and clone this repo.

```
git clone https://git.koh.cloud/fuchs/koh_terminal.git
```
Setup the correct permission on `koh_terminal`, like 

```
sudo chown -R www-data:www-data koh_terminal
```

Now you're able to aktivate the Theme in the `/admin` Area.


## Screenshot
![screenshot](screen.png)
<div class="container mt-4">
    <?php Theme::plugins('siteSidebar') ?>
</div>

Multiverse
==========

Multiverse is a one-page gallery with a fully functional lightbox and a "panel" system by [HTML5 UP](html5up.net).

It's published under the CCA 3.0 license.

Tools
-----

* Poptrox: https://github.com/ajlkn/jquery.poptrox
* Responsive Tools: https://github.com/ajlkn/responsive-tools

Usage
-----

To use the "About" panel use the plugin About. You can add an additional panel "Privacy" by downloading and activating the plugin Textarea.

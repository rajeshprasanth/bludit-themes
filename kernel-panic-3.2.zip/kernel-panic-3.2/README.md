# Kernel Panic theme for Bludit

## Compatible
- Bludit v3.x

## Author
- Diego

## Screenshot
![screenshot-kernel-panic](https://raw.githubusercontent.com/bludit-themes/kernel-panic/master/screenshot.png)
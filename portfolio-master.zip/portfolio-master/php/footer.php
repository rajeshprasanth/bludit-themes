<footer class="site-footer">
    <div class="wrap">
        <span class="text-center"><?php echo $site->footer(); ?></span> -     
        <span>Powered by <img style="width:16px" src="<?php echo DOMAIN_THEME_IMG.'bludit.png'; ?>"/><a target="_blank" href="https://www.bludit.com"> Bludit</a></span>
    </div>
</footer>
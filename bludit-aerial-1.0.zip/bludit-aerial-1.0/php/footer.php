<footer id="footer">
 	<?php echo $site->footer(); ?><a href="http://html5up.net"> HTML5 UP</a>
</footer>

	</div>
		</div>
		<script>
			window.onload = function() { document.body.classList.remove('is-preload'); }
			window.ontouchmove = function() { return false; }
			window.onorientationchange = function() { document.body.scrollTop = 0; }
		</script>

	</body>
</html> 
